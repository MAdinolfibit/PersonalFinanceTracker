
import random
from typing import List, Dict

class BudgetTips:
    def __init__(self):
        self.tips = [
            {
                "title": "Regola del 50/30/20",
                "description": "Dedica il 50% del reddito alle necessità, il 30% ai desideri e il 20% ai risparmi. Questa regola ti aiuterà a mantenere un equilibrio finanziario sano.",
                "category": "pianificazione"
            },
            {
                "title": "Traccia ogni spesa",
                "description": "Annota ogni transazione, anche quella più piccola. La consapevolezza è il primo passo verso il controllo finanziario. Spesso le piccole spese si accumulano più di quanto pensiamo.",
                "category": "controllo"
            },
            {
                "title": "Crea un fondo di emergenza",
                "description": "Risparmia almeno 3-6 mesi di spese essenziali in un fondo di emergenza. Questo ti proteggerà da imprevisti finanziari e ti darà tranquillità mentale.",
                "category": "risparmio"
            },
            {
                "title": "Rivedi il budget mensilmente",
                "description": "Analizza le tue spese ogni mese e aggiusta il budget di conseguenza. I bisogni cambiano nel tempo, e il tuo budget dovrebbe riflettere questi cambiamenti.",
                "category": "revisione"
            },
            {
                "title": "Elimina gli abbonamenti inutilizzati",
                "description": "Controlla regolarmente i tuoi abbonamenti e cancella quelli che non usi. Questi piccoli importi mensili possono accumularsi significativamente nel tempo.",
                "category": "ottimizzazione"
            },
            {
                "title": "Compra con una lista",
                "description": "Fai sempre la spesa con una lista preparata in anticipo. Questo ti aiuterà a evitare acquisti impulsivi e a rimanere entro il budget prestabilito.",
                "category": "controllo"
            },
            {
                "title": "Paga te stesso per primo",
                "description": "Appena ricevi lo stipendio, metti da parte la quota destinata ai risparmi. Tratta il risparmio come una spesa obbligatoria, non come quello che rimane.",
                "category": "risparmio"
            },
            {
                "title": "Usa la regola delle 24 ore",
                "description": "Per acquisti non essenziali sopra una certa soglia, aspetta 24 ore prima di comprare. Spesso scoprirai che l'impulso di acquisto passa e non ne hai davvero bisogno.",
                "category": "controllo"
            },
            {
                "title": "Automatizza i risparmi",
                "description": "Imposta trasferimenti automatici verso il conto risparmi. L'automazione riduce la tentazione di spendere quei soldi e rende il risparmio un'abitudine.",
                "category": "risparmio"
            },
            {
                "title": "Confronta sempre i prezzi",
                "description": "Prima di fare acquisti importanti, confronta i prezzi su diversi negozi o piattaforme online. Anche un piccolo sconto può fare una grande differenza nel lungo termine.",
                "category": "ottimizzazione"
            }
        ]
    
    def get_random_tip(self) -> Dict[str, str]:
        """Ottieni un consiglio casuale"""
        return random.choice(self.tips)
    
    def get_tips_by_category(self, category: str) -> List[Dict[str, str]]:
        """Ottieni consigli per categoria"""
        return [tip for tip in self.tips if tip["category"] == category]
    
    def get_all_tips(self) -> List[Dict[str, str]]:
        """Ottieni tutti i consigli"""
        return self.tips.copy()
